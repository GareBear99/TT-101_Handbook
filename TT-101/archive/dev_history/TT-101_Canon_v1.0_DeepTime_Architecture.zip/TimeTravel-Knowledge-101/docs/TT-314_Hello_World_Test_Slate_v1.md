# TT-314 — “Hello World” Test Slate (v1)

This is the **first end-to-end test artifact** for TT-307.

## 1) Payload
`HELLO TT-101 :: OPTICAL SLATE TEST v1`

## 2) What This Proves
- The block can be engraved and later read
- The finder/timing structures survive minor damage
- A future reader can:
  1) orient the grid
  2) extract bits
  3) reconstruct bytes
  4) validate integrity via hash

## 3) Files Provided
- `artifacts/slate_hello_world_v1.svg` — vector master (laser friendly)
- `artifacts/slate_hello_world_v1.png` — preview raster
- `tools/generate_slate_hello_world.py` — deterministic generator used to produce both

## 4) Verification
The generator prints:
- payload bytes
- SHA-256 of payload
- grid size N
- reserved structure map

Compare generator output to the etched slate’s engraved metadata.

## 5) Next Test
- Abrasion test coupon (sand/brush) on a sample plate
- Re-scan / re-transcribe
- Confirm hash still matches
