# TT-318 — Canon Governance Hardening (Fail-Closed)

Purpose: Prevent silent canon capture, drift, and unauthorized rewrites.

## Governance Objects
- **Canon**: append-only documents + hashes
- **Manifest**: integrity snapshot
- **Canon Log**: append-only human-readable change log

## Hard Rules
1) **Append-only canon**
   - Old files are never edited without a superseding entry.
2) **Two-person rule (minimum)**
   - Any canon update requires independent review (human process).
3) **Multi-sig canon acceptance (network tier)**
   - TT-701+ nodes accept canon updates only with threshold signatures.
4) **Emergency Freeze**
   - If signatures conflict or validator fails → freeze updates; publish incident report.

## Key Rotation / Revocation (Conceptual)
- Maintain a revocation list for compromised keys.
- Compromised nodes quarantine until re-provisioned.

## Completion Criteria
- Canon cannot change without:
  - passing validation
  - producing a new manifest hash snapshot
  - recording an append-only canon log entry
