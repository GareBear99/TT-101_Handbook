# TT-321 — Incident Response & Canon Freeze Template

When integrity is uncertain, the system must **fail closed**.

## Trigger Conditions
- Validator fails (`make validate` non-zero)
- Manifest mismatch across mirrors
- Suspected key compromise
- Conflicting canon branches
- Unauthorized edits detected

## Immediate Actions (0–24h)
1) Freeze canon updates
2) Snapshot current manifests from all mirrors
3) Publish incident note referencing the last known-good manifest hash
4) Quarantine suspect branch/mirror

## Investigation
- Identify changed files
- Verify hashes
- Determine who/what changed and why

## Recovery
- Roll forward using append-only corrections
- Rotate keys if needed
- Re-enable updates only after validation passes

## Postmortem (Required)
- timeline
- root cause
- mitigation applied
- new controls
