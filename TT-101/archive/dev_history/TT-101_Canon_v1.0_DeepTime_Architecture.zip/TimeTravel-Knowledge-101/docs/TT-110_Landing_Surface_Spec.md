# TT-110 — Landing Surface Spec (DARPA-Grade)

Objective: The landing page must guide readers with **progressive disclosure** and never overload first contact.

## Primary User Paths
1) **New reader (skeptical):** understand purpose + safety posture in 60 seconds.
2) **Builder:** follow the “Build Path” and run validation.
3) **Archivist:** produce passive archive artifacts (slates/paper/metal).

## Progressive Disclosure Rules
- Show **Start Here** first: TT-101 → TT-201 → TT-999
- Hide implementation tiers behind clear buckets:
  - Passive Archive (TT-303 + TT-307..314)
  - Governance & Site (TT-401..404 + TT-318)
  - Collapse & Long Horizon (TT-501.. + TT-601..)
  - Network Expansion (TT-701.. + TT-801..)

## Landing Page Must Include
- Safety posture (fail-closed, no high-impact dumps)
- Threat model headline (loss, corruption, drift)
- “Works without time travel” statement (core legitimacy)
- Deterministic commands:
  - `make validate`
  - generate TT-314 artifact

## Anti-Misuse Wording
- Explicitly disallow weaponization and political manipulation.
- Frame as **archival continuity engineering**.
