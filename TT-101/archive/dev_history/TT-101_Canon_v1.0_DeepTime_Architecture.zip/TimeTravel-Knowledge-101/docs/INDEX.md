# TT Canon Index

This index is the **single source of truth** for navigating TT documents.
If a file exists but is not in this index, it is treated as **non-canon** until indexed.

## Concept
- [TT-101 Conceptual Framework](TT-101.md)

## Protocol
- [TT-201 Timeproof Continuity Protocol](TT-201_Timeproof_Continuity_Protocol.md)
- [TT-202 Pivot Window Model](TT-202_Pivot_Window_Model.md)
- [TT-203 Minimal Message Architecture](TT-203_Minimal_Message_Architecture.md)
- [TT-204 Handshake Specification](TT-204_Handshake_Spec.md)
- [TT-205 Distributed Archive Specification](TT-205_Distributed_Archive_Spec.md)

## 1000-Year Vault
- [TT-301 Vault Overview](TT-301_1000yr_Vault_Overview.md)
- [TT-302 Hibernation Doctrine](TT-302_Hibernation_Doctrine.md)
- [TT-303 Tri-Format Archive](TT-303_Tri-Format_Archive.md)
- [TT-304 Compute Degradation Modes](TT-304_Compute_Degradation_Modes.md)
- [TT-305 Robotics Minimal Set](TT-305_Robotics_Minimal_Set.md)
- [TT-306 Consumables & Corrosion](TT-306_Consumables_and_Corrosion.md)

## Optical Slate Passive Core
- [TT-307 Optical Slate Archive Core](TT-307_Optical_Slate_Archive_Core.md)
- [TT-308 Decoding Ladder (Rosetta)](TT-308_Decoding_Ladder_Rosetta.md)
- [TT-309 Erosion-Tolerant Error Correction](TT-309_Erosion_Tolerant_Error_Correction.md)
- [TT-310 Slate RAID Block Format](TT-310_Slate_RAID_Block_Format.md)
- [TT-311 Materials & Engraving Depth](TT-311_Materials_and_Engraving_Depth.md)
- [TT-312 Laser Workflow, QA, and Copying](TT-312_Laser_Workflow_QA_and_Copying.md)
- [TT-313 Optical Slate Block Spec v1](TT-313_Optical_Slate_Block_Spec_v1.md)
- [TT-314 Hello World Test Slate v1](TT-314_Hello_World_Test_Slate_v1.md)

## Site / Legal / Ethics
- [TT-401 Geological Site Selection](TT-401_Geological_Site_Selection.md)
- [TT-402 Legal Continuity Framework](TT-402_Legal_Continuity_Framework.md)
- [TT-403 Rediscovery Pathway](TT-403_Rediscovery_Pathway.md)
- [TT-404 AI Ethical Constraints](TT-404_AI_Ethical_Constraints.md)

## Collapse Resilience
- [TT-501 Collapse Resilience Model](TT-501_Collapse_Resilience_Model.md)
- [TT-502 Post-Event Reboot Manual](TT-502_Post_Event_Reboot_Manual.md)
- [TT-503 Non-Disruptive Breadcrumbs](TT-503_Non_Disruptive_Breadcrumbs.md)
- [TT-504 Cosmological Risk Modeling](TT-504_Cosmological_Risk_Modeling.md)

## 10,000-Year Expansion
- [TT-601 10,000-Year Outlook](TT-601_10000yr_Outlook.md)
- [TT-602 Interplanetary/Interstellar Communications](TT-602_Interplanetary_Interstellar_Comms.md)
- [TT-603 Multi-Planet Deployment](TT-603_MultiPlanet_Deployment.md)
- [TT-604 Self-Replication Fab Stack](TT-604_SelfReplication_FabStack.md)
- [TT-605 Civilization Stages](TT-605_Civilization_Stages_and_Where_We_Are.md)
- [TT-606 Time-Travel Acceleration Map](TT-606_TimeTravel_Acceleration_Map.md)

## Solar System Continuity Network
- [TT-701 Network Spec](TT-701_Solar_System_Continuity_Network_Spec.md)
- [TT-702 Minimum Viable Outpost BOM](TT-702_Minimum_Viable_Outpost_BOM.md)
- [TT-703 Node Synchronization Protocol](TT-703_Node_Synchronization_Protocol.md)
- [TT-704 Deep-Time Governance Model](TT-704_Deep_Time_Governance_Model.md)
- [TT-705 Post-Scarcity Automation Map](TT-705_Post_Scarcity_Automation_Map.md)
- [TT-706 10,000-Year Completion Definition](TT-706_10Kyr_Completion_Definition.md)

## Interstellar Continuity
- [TT-801 Interstellar Seed Architecture](TT-801_Interstellar_Seed_Architecture.md)
- [TT-802 Relativistic Delay Governance](TT-802_Relativistic_Delay_Governance.md)
- [TT-803 Generation Ship Archive Model](TT-803_Generation_Ship_Archive_Model.md)
- [TT-804 Autonomous Probe Continuity Nodes](TT-804_Autonomous_Probe_Continuity.md)
- [TT-805 100,000-Year Deep-Time Model](TT-805_100Kyr_Deep_Time_Model.md)
- [TT-806 Final Completion Criteria](TT-806_Final_Completion_Criteria.md)

## Reference
- [Glossary](glossary.md)

## Master Canon
- [TT-999 Master Canon v1](TT-999_Master_Canon_v1.md)

## Surface & Operations
- [TT-110 Landing Surface Spec](TT-110_Landing_Surface_Spec.md)
- [TT-318 Canon Governance Hardening](TT-318_Canon_Governance_Hardening.md)
- [TT-319 Red Team Adversarial Report](TT-319_Red_Team_Adversarial_Report.md)
- [TT-320 Slate Materials Testing Plan](TT-320_Slate_Materials_Testing_Plan.md)
- [TT-321 Incident Response & Freeze Template](TT-321_Incident_Response_and_Freeze_Template.md)

## Diagrams
- [Civilization Stage Map (SVG)](../artifacts/civilization_stage_map_v1.svg)

## Self-Sufficiency
- [TT-324 Self-Fabrication & Self-Sufficiency Doctrine](TT-324_Self_Fabrication_and_Self_Sufficiency_Doctrine.md)
- [TT-325 Bootstrap vs Deep-Time Substrate](TT-325_Bootstrap_vs_DeepTime_Substrate.md)
- [TT-326 Anti-Ideology / Anti-Cult Guardrails](TT-326_Anti_Ideology_and_Anti_Cult_Guardrails.md)
- [TT-327 Distributed Signing & Verification Policy](TT-327_Distributed_Signing_and_Verification_Policy.md)

## Certification
- [TT-328 Optical Slate Certification Standard](TT-328_Optical_Slate_Certification_Standard.md)
