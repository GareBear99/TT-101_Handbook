# TT-325 — Bootstrap vs Deep-Time Substrate (v1)

This file separates the system into two realities:

## A) Bootstrap (Present-Civilization Interface)
Used when civilization and supply chains exist.

Characteristics:
- internet mirrors
- CI validation
- convenient fabrication tools (laser/CNC)
- optional funding/logistics to accelerate copying

Bootstrap is not required for long-term survival; it is a speed multiplier.

## B) Deep-Time Substrate (Collapse-Proof Core)
Used when infrastructure, money, and institutions fail.

Characteristics:
- passive artifacts (optical slate / etched plates)
- manual decoding ladder
- mechanical reproduction instructions
- redundant caches across geography

The substrate is the **real system**.
Bootstrap is an on-ramp.

## Rule
No design decision may break the substrate in exchange for bootstrap convenience.
