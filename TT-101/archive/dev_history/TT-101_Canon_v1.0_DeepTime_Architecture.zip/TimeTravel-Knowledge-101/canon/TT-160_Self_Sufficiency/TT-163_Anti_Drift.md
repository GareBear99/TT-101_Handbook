# TT-326 — Anti-Ideology / Anti-Cult Guardrails (v1)

Purpose: Prevent the TT archive from drifting into prophecy, ideology, or coercion.

## Non-Negotiable Statements
- This is an **engineering archive**, not a metaphysical claim.
- No person, institution, or group is “chosen” by this archive.
- The archive grants no moral authority.
- The archive must not be used to recruit, coerce, or manipulate.
- Any attempt to treat canon as scripture is a failure mode.

## Interpretation Discipline
- Prefer operationally testable claims.
- Mark speculation as speculation.
- When uncertain, fail closed and preserve multiple hypotheses.

## Removal of Founder Authority
- The original author has no override privileges.
- Canon is defined by verifiable integrity (manifest + signatures), not by identity.

## Required Surface Warning
Landing pages and summaries must include a short “anti-cult” paragraph:
> This project is continuity engineering. It is not prophecy, ideology, or authority.
