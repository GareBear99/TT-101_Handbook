# TT-804 — Autonomous Probe Continuity Nodes

Robotic probes may establish interstellar continuity before humans arrive.

Probe Requirements:
- Hardened passive archive core
- Low-power compute island
- Radiation shielding
- Long-duration power (hibernation-first)

If probe fails:
Archive must remain readable for future explorers.
