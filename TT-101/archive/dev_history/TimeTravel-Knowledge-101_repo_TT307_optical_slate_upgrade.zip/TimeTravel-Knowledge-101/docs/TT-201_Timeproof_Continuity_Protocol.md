# TT-201 — Timeproof Continuity Protocol

Core Components:

1) Pivot Window
- Defined time band where intervention has maximal leverage.
- Must be condition-based, not vague.

2) Minimal-Impact Message Budget
- 1 identity proof
- 1 direction
- 1 warning
- 1 tool
No civilization-scale disruption.

3) 3-Part Handshake
- Private Phrase Seed
- Artifact Proof
- Behavioral Verification

4) Distributed Archive Base
- Redundant locations
- Hash-chained manifest
- Human-readable fallback

5) Attractor Engineering
- Skill stacking
- Resilience building
- Capital preservation
- Health and cognitive continuity

Purpose:
Guarantee usefulness whether time travel exists or not.
