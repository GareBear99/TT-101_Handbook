# TT-310 — Slate RAID Block Format (Physical Dataset Assembly)

Treat slates like a physical RAID array.

## Block Anatomy
- Alignment frame (thick border)
- Finder patterns (corners)
- Version tag
- Block ID (human-readable + encoded)
- Payload bits
- Embedded checksum/hash
- Parity metadata

## Reconstruction Rules
- Blocks are ordered by Block ID
- Missing blocks can be reconstructed if parity blocks exist
- Multiple identical copies across sites increase survival probability

## Why RAID-on-Stone
Because “some blocks will be lost.”
Design for graceful degradation, not perfection.
