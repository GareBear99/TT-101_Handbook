# TT-202 — Pivot Window Model

A Pivot Window is a bounded period where small input causes large trajectory shift.

Constraints:
- You can act immediately
- Environment is stable enough for execution
- Decision tree branches are wide

Trigger Types:
- Date-based
- Milestone-based
- Condition-based

Success condition:
Clear measurable action taken within window.
