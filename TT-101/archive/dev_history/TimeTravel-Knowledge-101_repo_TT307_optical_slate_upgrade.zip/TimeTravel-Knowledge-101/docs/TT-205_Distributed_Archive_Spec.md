# TT-205 — Distributed Archive Specification

Archive must survive:
- Infrastructure collapse
- Institutional decay
- Technological regression

Layers:
1) Human-readable
2) Machine-readable
3) Executable bootstrap

Integrity:
- SHA-256 manifest
- Append-only log
- Multi-location redundancy
