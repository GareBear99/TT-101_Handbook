# TT-204 — Handshake Specification

Fail-closed identity verification model.

A) Private Phrase Seed
- Created once
- Stored sealed
- Never publicly revealed

B) Artifact Proof
- Structured object containing layered verifiable complexity

C) Behavioral Proof
- Decision pattern validation
- Non-trivia questions

Rule:
Failure at any stage invalidates intervention.
