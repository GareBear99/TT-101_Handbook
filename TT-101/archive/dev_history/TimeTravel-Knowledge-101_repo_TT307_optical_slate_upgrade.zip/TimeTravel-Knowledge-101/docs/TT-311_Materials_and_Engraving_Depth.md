# TT-311 — Materials & Engraving Depth (Survivability)

## Preferred Materials (Durable)
- Granite / basalt (petroglyph-grade longevity)
- Ceramic / porcelain plates (stable if protected)
- Titanium / stainless steel (deep etch; corrosion resistant)
- Fused silica / sapphire (extreme stability; specialized fabrication)

## Avoid
- Polymers
- Coatings/paints as primary carriers
- Adhesive-bonded stacks

## Engraving Requirement
Use **deep engraving**, not surface discoloration.
- deep grooves survive abrasion
- shallow marks fade

## Environment Guidance
- dry, stable geology
- sealed chambers if possible
- minimize thermal cycling and moisture
