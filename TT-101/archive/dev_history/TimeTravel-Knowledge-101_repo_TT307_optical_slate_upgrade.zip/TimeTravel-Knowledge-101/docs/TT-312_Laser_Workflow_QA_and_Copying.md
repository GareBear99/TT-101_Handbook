# TT-312 — Laser Workflow, QA, and Copying

## Pipeline
1) Canon selection (what to store in passive layer)
2) Chunking + parity generation (TT-310)
3) Render blocks to etchable grids
4) Laser etch test coupon
5) Scan/verify (optical verification)
6) Final etch + post-etch inspection
7) Duplicate slates and store geographically

## QA Checks
- block alignment tolerance
- readability at distance + magnification
- checksum verification from scan
- abrasion test on sample

## Copying Doctrine
A future civilization should be able to:
- hand-copy the decoding ladder
- mechanically trace block grids
- reproduce the archive even without modern scanners
