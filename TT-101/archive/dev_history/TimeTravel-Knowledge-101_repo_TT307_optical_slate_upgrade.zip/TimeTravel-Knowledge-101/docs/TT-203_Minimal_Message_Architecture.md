# TT-203 — Minimal Message Architecture

Design principle: Small message, large impact.

Allowed:
- Authentication proof
- Direction
- Warning
- Tool/checklist

Disallowed:
- Public technology demonstrations
- Political manipulation
- Financial speculation dumps
- Civilization-scale knowledge injection

Why:
Minimizes ripple destabilization.
