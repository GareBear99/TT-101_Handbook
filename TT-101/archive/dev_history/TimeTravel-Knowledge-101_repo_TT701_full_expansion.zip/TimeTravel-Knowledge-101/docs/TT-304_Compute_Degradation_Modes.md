# TT-304 — Compute Degradation Modes

Phase A: Full AI Custodian
Phase B: Deterministic Librarian
Phase C: Passive Archive Only

System must gracefully downgrade.