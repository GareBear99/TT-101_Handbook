# TT-502 — Post-Event Reboot Manual (Template)

Audience: Future discoverers after a disruption.

## 0) Safety First
- Do not attempt high-energy experiments.
- Do not weaponize information.
- Prioritize water, shelter, health.

## 1) Confirm Authenticity
- Verify the integrity manifest (hashes / checksums).
- Cross-check multiple copies stored in separate chambers.

## 2) Restore Readability
- Start from Human-Readable Layer.
- Follow the decoding ladder to Machine-Readable Layer.
- Use printed bootstrap instructions to rebuild viewers.

## 3) Minimal Reconstruction Path
- Reconstruct text + diagrams first.
- Reconstruct protocol templates next.
- Only then rebuild software tooling.

## 4) Ethical Guardrails
- Preserve life and stability.
- Avoid civilization-scale destabilization.

Outcome:
A working “knowledge seed” without requiring modern infrastructure.