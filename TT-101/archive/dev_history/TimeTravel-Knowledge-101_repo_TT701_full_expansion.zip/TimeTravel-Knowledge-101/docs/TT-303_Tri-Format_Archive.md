# TT-303 — Tri-Format Archive

1. Human-readable (metal + paper)
2. Machine-readable (error-corrected digital)
3. Executable bootstrap (minimal viewer code)

Each layer explains how to decode the next.