# TT-302 — Hibernation Doctrine

Vault default state: asleep.

Operational pattern:
- Wake quarterly for integrity checks
- Annual deep maintenance cycle
- Otherwise low-energy standby

Minimize wear. Maximize longevity.