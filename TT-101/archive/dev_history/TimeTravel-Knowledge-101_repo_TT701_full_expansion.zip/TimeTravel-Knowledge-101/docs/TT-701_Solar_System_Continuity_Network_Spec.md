# TT-701 — Solar System Continuity Network (Spec)

Goal: Define a standardized architecture for multi-node continuity across planets.

## Node Registry Format
Each node publishes:
- Node ID (public key derived)
- Physical class (Vault / Relay / Factory / Research)
- Energy profile
- Storage tier capacities
- Canon version + manifest hash

## Canon Acceptance Rules
- Append-only log
- Multi-signature threshold (e.g., 3/5 trusted nodes)
- Hash-chain continuity required
- Divergent branches quarantined until reconciled

## Failure Handling
- Node isolation does not invalidate network
- Resync occurs opportunistically
- Old canon versions remain accessible

Objective:
A solar-system-scale archive with cryptographic continuity.
