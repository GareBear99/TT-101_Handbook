# TT-306 — Consumables & Corrosion

Primary threats:
- Moisture
- Dust
- Lubricant degradation
- Seal failure

Mitigation:
- Sealed chambers
- Desiccant reserves
- Dry-bearing systems
- Massive consumable stockpile