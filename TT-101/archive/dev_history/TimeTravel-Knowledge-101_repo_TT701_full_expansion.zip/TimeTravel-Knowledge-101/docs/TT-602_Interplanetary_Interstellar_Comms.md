# TT-602 — Interplanetary & Interstellar Communications

## The Real Constraint: Latency
- Earth↔Mars: minutes (variable)
- Beyond: hours, days, years

So the architecture must be **delay-tolerant**:
- store-and-forward routing
- offline-first data models
- cryptographic integrity and receipts

## Recommended Model: DTN + Append-Only Canon
Use Delay/Disruption Tolerant Networking (DTN) concepts:
- bundle messages
- relay nodes
- custody transfer
- opportunistic forwarding

For TT-101:
- updates are **append-only**
- each update is signed and hash-chained
- nodes synchronize when links exist

## What You Transmit
1) Small: manifests, indexes, hashes, “what changed”
2) Medium: new docs, diagrams, protocols
3) Large: media datasets (optional)

Design rule: *The canon must be reconstructable from the small tier.*

## Authentication
- per-node keys
- quorum threshold for “canon acceptance” (multi-sig)
- fail-closed: unknown signatures are quarantined

## Why This Matters Even Without Time Travel
This is the same infrastructure required for:
- long-term archives
- resilient civilization comms
- interplanetary governance logs

Time travel (if it ever exists) would only increase the value of having a validated canon.
