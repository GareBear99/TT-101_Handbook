# TT-403 — Rediscovery Pathway

Vault must be discoverable but not disruptive.

Methods:
- Time capsule markers
- Public academic references
- Geographic registry entries
- Encoded global coordinate hints

Rules:
- No dangerous technology instructions
- Focus on knowledge preservation
- Discovery should not destabilize society