# TT-404 — AI Ethical Constraint Layer

AI custodian must operate under hard limits.

Rules:
- Preserve archive integrity above all
- No autonomous expansion
- No resource acquisition beyond budget
- Fail-closed if uncertainty detected
- Immutable capability caps

Design principle:
Preservation, not domination.