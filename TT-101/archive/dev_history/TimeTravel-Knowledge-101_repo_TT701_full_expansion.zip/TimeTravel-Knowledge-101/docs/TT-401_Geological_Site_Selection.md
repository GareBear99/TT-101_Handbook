# TT-401 — Geological Site Selection

Objective: Maximize 1000-year physical survivability.

Preferred characteristics:
- Stable bedrock (cratonic regions)
- Low seismic activity
- Minimal groundwater movement
- No floodplain exposure
- Politically neutral or uninhabited territory

Avoid:
- Coastal erosion zones
- Permafrost melt regions
- Tectonic boundaries
- Volcanic fields

Design principle:
Physical stability > accessibility.