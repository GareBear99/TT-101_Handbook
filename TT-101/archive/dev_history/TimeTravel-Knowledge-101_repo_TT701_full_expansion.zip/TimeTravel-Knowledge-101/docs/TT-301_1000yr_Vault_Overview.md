# TT-301 — 1000-Year Continuity Vault Overview

Passive immortality + Active stewardship.

Layer 1: Passive Archive
- Etched metal plates
- Acid-free books
- Redundant sealed chambers

Layer 2: Active Stewardship
- Maintenance robotics
- Fabrication capability
- Compute islands + cold spares

Core rule: Archive must survive even if robotics fail.