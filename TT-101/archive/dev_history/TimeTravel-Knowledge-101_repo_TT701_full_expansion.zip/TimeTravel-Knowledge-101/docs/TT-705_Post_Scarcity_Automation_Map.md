# TT-705 — Post-Scarcity Automation Map

Automation enables higher resilience and multi-planet expansion.

Stages:
- Human-operated fabrication
- Human-supervised automation
- Semi-autonomous factories
- Fully autonomous maintenance nodes

Constraints:
- Resource budgets
- Capability caps
- Ethical override layers

Outcome:
Automation serves preservation, not uncontrolled growth.
