# TT-305 — Robotics Minimal Set

- Gantry rail system
- 6-axis arm
- CNC mill/lathe
- Polymer printer
- Inspection station

Reduce complexity. Standardize parts.