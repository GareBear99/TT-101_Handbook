# TT-101 Roadmap (Canon)

## TT-101 — Conceptual Framework
- Time models (fixed/self-consistent, branching, unknown)
- Entropy/time-dilation discussion
- Timeproof Continuity Protocol (TT-201)

## TT-201 — Protocol Layer
- Pivot Window
- Minimal-Impact Message Budget
- 3-Part Handshake
- Distributed Archives + Integrity

## TT-301 — 1000-Year Vault Architecture
- Passive archive + active stewardship
- Hibernation doctrine
- Tri-format archive
- Compute degradation modes
- Minimal robotics set
- Consumables/corrosion strategy

## TT-401 — Site / Legal / Rediscovery / Ethics
- Geological site selection
- Legal continuity framework
- Rediscovery pathway
- AI ethical constraint layer

## TT-501 — Completion Tier (Resilience)
- Collapse resilience model
- Post-event reboot manual
- Non-disruptive breadcrumbs
- Cosmological/planetary risk modeling

## Definition of “Complete” (v1)
A repo is “complete” when:
1) A human-readable archive can be reconstructed with minimal tools
2) Integrity can be verified via manifest
3) A pivot-window intervention can be authenticated and applied safely
4) The vault concept survives 1000-year failure modes (passive-first)
