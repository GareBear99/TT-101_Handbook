# Canon Log (Append-Only)

Rules:
- Add new entries at the top.
- Never edit old entries; supersede with a new entry.
- Every entry must reference a manifest hash snapshot.

## 2026-03-02 — TT-307 Optical Slate Tier added
- Added TT-307..TT-312 (optical slate passive archive)
- Updated navigation + manifest

