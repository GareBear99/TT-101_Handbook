# Safety & Ethics

This repository is dedicated to **continuity-safe** and **non-destructive** reasoning.

## Not allowed
- Plans to harm people, overthrow governments, cause violence, or destabilize society
- Instructions for wrongdoing (fraud, weapons, sabotage)
- “Civilization rewrite” strategies

## Allowed
- Personal decision support and resilience planning
- Nonviolent, consent-aware hypothetical protocols
- Philosophy and theory discussion

## Principle
If time travel were ever possible, the only ethical interventions would be:
- minimal,
- private,
- and aimed at preventing harm rather than creating it.
