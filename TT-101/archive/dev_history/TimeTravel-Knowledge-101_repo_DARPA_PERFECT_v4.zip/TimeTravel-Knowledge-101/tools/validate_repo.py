#!/usr/bin/env python3
"""
TT-101 Repo Validator (Fail-Closed)
- No silent failures: exits non-zero with actionable errors.
Checks:
1) ROADMAP.md has no regex artifacts (e.g., '\1')
2) docs/INDEX.md exists and lists only existing files
3) manifest/hashes.txt exists and matches file hashes (excluding itself)
"""
from __future__ import annotations
import hashlib, os, sys, re, pathlib

ROOT = pathlib.Path(__file__).resolve().parents[1]

def sha256_file(p: pathlib.Path) -> str:
    h = hashlib.sha256()
    with p.open("rb") as f:
        for chunk in iter(lambda: f.read(1024*1024), b""):
            h.update(chunk)
    return h.hexdigest()

def fail(msg: str) -> None:
    print("VALIDATION FAIL:", msg)
    sys.exit(2)

def main() -> None:
    roadmap = (ROOT / "ROADMAP.md")
    if not roadmap.exists():
        fail("Missing ROADMAP.md")
    txt = roadmap.read_text(encoding="utf-8", errors="replace")
    if "\\1" in txt or "\x01" in txt:
        fail("ROADMAP.md contains a regex substitution artifact (e.g. '\\\\1'). Remove it.")

    idx = ROOT / "docs" / "INDEX.md"
    if not idx.exists():
        fail("Missing docs/INDEX.md")
    idx_txt = idx.read_text(encoding="utf-8", errors="replace")
    links = re.findall(r"\(([^)]+\.md)\)", idx_txt)
    for link in links:
        p = (ROOT / "docs" / link).resolve()
        if not p.exists():
            fail(f"INDEX.md links to missing file: docs/{link}")


    # TT-314 artifact checks
    # Required ops hardening docs
    # Self-sufficiency and anti-drift required docs
    for rel in [
        "docs/TT-324_Self_Fabrication_and_Self_Sufficiency_Doctrine.md",
        "docs/TT-325_Bootstrap_vs_DeepTime_Substrate.md",
        "docs/TT-326_Anti_Ideology_and_Anti_Cult_Guardrails.md",
        "docs/TT-327_Distributed_Signing_and_Verification_Policy.md",
        "release/RELEASE_TEMPLATE.txt",
    ]:
        p = ROOT / rel
        if not p.exists():
            fail(f"Missing required file: {rel}")

    for rel in [
        "docs/TT-110_Landing_Surface_Spec.md",
        "docs/TT-318_Canon_Governance_Hardening.md",
        "docs/TT-319_Red_Team_Adversarial_Report.md",
        "docs/TT-320_Slate_Materials_Testing_Plan.md",
        "docs/TT-321_Incident_Response_and_Freeze_Template.md",
        "artifacts/civilization_stage_map_v1.svg",
    ]:
        p = ROOT / rel
        if not p.exists():
            fail(f"Missing required file: {rel}")

    for rel in ["artifacts/slate_hello_world_v1.svg", "tools/generate_slate_hello_world.py"]:
        p = ROOT / rel
        if not p.exists():
            fail(f"Missing required artifact: {rel}")

    manifest = ROOT / "manifest" / "hashes.txt"
    if not manifest.exists():
        fail("Missing manifest/hashes.txt")
    man_lines = [ln.strip() for ln in manifest.read_text(encoding="utf-8", errors="replace").splitlines()]
    pairs = []
    for ln in man_lines:
        if not ln or ln.startswith("TT-101 Integrity Manifest") or ln.startswith("Generated:"):
            continue
        # format: <hash>  <path>
        if "  " not in ln:
            continue
        digest, rel = ln.split("  ", 1)
        rel = rel.strip()
        if rel == "manifest/hashes.txt":
            continue
        pairs.append((digest.strip(), rel))

    # Verify all listed files exist and match
    for digest, rel in pairs:
        p = ROOT / rel
        if not p.exists():
            fail(f"Manifest references missing file: {rel}")
        actual = sha256_file(p)
        if actual != digest:
            fail(f"Hash mismatch for {rel}: manifest={digest} actual={actual}")

    print("VALIDATION OK")
    sys.exit(0)

if __name__ == "__main__":
    main()
